# Credit Card Checkout

A Pen created on CodePen.

Original URL: [https://codepen.io/andrade_nicko/pen/gxbBwv](https://codepen.io/andrade_nicko/pen/gxbBwv).

