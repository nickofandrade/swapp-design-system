# App Icon

A Pen created on CodePen.

Original URL: [https://codepen.io/andrade_nicko/pen/MvaGzV](https://codepen.io/andrade_nicko/pen/MvaGzV).

